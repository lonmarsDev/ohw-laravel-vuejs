<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class SettingsController extends Controller {

  var $user;
  var $country;
  
  public function __construct()
  {
    // $this->middleware('auth');
    
    /** Seed a user id */  
  
    // $user = User::find();
    $this->user = [
      'id' => '1',
      'username'=> 'test',
      'email' => 'test@test.com',
      'fname' => 'test',
      'lname' => 'test',
      'company' => 'test',
      'address'=> 'test',
      'address_2'=> 'test',
      'city'=> 'test',
      'zip'=> '123',
      'countryName'=> 'Dummy',
      'country'=> 'dummy',
      'phone'=> '',
      'vat_tax'=> '123',
      'timezone'=> 'timezone2',
      'date_format'=> 3,
      'currency_format'=> 2

    ];

    $this->country = [
      'dummy' => [
          'countryId' => 'dummy',
          'name' => 'Dummy'
      ],
      'dummy2' => [
          'countryId' => 'dummy2',
          'name' => 'Dummy 2'
      ]
    ];
    $this->timezone = [
      'timezone1' => [
          'timezoneId' => 'timezone1',
          'name' => 'Timezone 1'
      ],
      'timezone2' => [
          'timezoneId' => 'timezone2',
          'name' => 'Timezone 2'
      ]
    ];
  }

  public function contact()
  {
    return view('settings.contact')->with([
      'user' => $this->user,
      'country' => $this->country
    ]);
  }
  public function details()
  {
    return view('settings.details')->with([
      'user' => $this->user,
      'timezone' => $this->timezone,
    ]);
  }

}

?>